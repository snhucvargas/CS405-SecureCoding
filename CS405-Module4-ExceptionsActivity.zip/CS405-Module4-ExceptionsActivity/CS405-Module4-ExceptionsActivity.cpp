// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

/*
* This is my custom exception which is derived from the standard exception.
* I overrode the what() method to specify that this is a custom exception being thrown.
*/
class MyException : public std::exception {
    public:
        const char* what() {
            return "The custom exception was thrown. ";
        }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // I added a standard exception here based on the <exception> header.
    // I included the argument "Standard Exception. " to help with debugging.
    throw std::exception("Standard Exception. ");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // I am wrapping the if statement in a try-catch block so that the exception thrown by
    // do_even_more_custom_application_logic is caught.
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // This line will display useful information for debugging and includes the what() method.
        // The purpose of the catch block is to allow the program to continue processing.
        std::cerr << "do_even_more_custom_application_logic encountered an error: " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // My custom exception is thrown after the output to help with debugging so that I know when
    // and where the exception is thrown.
    std::cout << "Leaving Custom Application Logic." << std::endl;
    throw MyException();


}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // I added an if-else statement to check if the floating point denominator argument is zero.
    if (den != 0.0f) {
        return (num / den);
    }
    else {
        // Den was found to be zero. Proceed to throw a runtime_error. I found this exception to be
        // the most suitable based on the documentation I found for standard C++ exceptions.
        // I have included an argument to help with debugging and specifying the cause of the error.
        throw std::runtime_error("Divide by zero");
    }
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // I added a try-catch block to handle the exception thrown by divide().
    try {
        auto result = divide(numerator, denominator);
        // I relocated the output statement here so that it is within the same scope as result's initialization.
        // This prevents the compiler errors and warnings found when it was excluded from the try block.
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {
        // I included a message specifying the source of the error to assist with debugging.
        std::cerr << "do_division encountered an error: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    // I wrapped the main function in a try block with multiple catch blocks per the TODO instructions.
    try {
        do_division();
        do_custom_application_logic();
    }
    // The first catch should be my custom exception
    catch (MyException& err) {
        // I included a message to help with debugging. This indicates that the do_custom_application_logic
        // was called and threw the exception.
        std::cout << "do_custom_application_logic encountered an error: " << err.what() << std::endl;
    }
    // The second catch should be for std::exception
    catch (std::exception& e) {
        // I included a message to assist with debugging. It indicates that a divide by 0 error took place
        // because divide is the only portion of the code that throws std::exception.
        std::cout << "A standard exception for divide by 0 has been caught." << e.what() << std::endl;
    }
    // Lastly, the catch-all block should be added.
    catch (...) {
        // The message is generic and indicates that all uncaught exceptions should be handled here.
        std::cout << "All remaining exceptions should be caught here." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
